<div class="footer">
    All rights reserved @<a href="https://github.com/Sabrina-Sumona/">Sabrina Naorin Sumona</a>
</div>